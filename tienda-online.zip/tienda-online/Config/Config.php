<?php
const BASE_URL = "http://localhost/tienda-online/";
const HOST = "localhost";
const USER = "root";
const PASS = "";
const DB = "tienda-online";
const CHARSET = "charset=utf8";
const TITLE = "BISON TIENDA";
const MONEDA = "MXN";
const CLIENT_ID = "";

/*const USER_SMTP = "Tu correo";
const PASS_SMTP = "contraseña generada para esta aplicacion";
const PUERTO_SMTP = 465;
const HOST_SMTP = "smtp.gmail.com";*/
?>
